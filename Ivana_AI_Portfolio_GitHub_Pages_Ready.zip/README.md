# AI Operations & People Analytics Portfolio — GitHub Pages

These files are ready for static hosting. The entire four-case-study portfolio,
including the interactive recruiting/retention dashboard, is in `index.html`.
No build tools, libraries, or external assets are needed.

DEPLOY
1. On GitHub, create a PUBLIC repository, e.g. `ai-operations-portfolio`.
2. Extract this ZIP and upload `index.html` and `.nojekyll` into the repository root.
3. Open repository Settings > Pages; choose `Deploy from a branch`,
   `main` and `/(root)`, then save.
4. When GitHub publishes, the portfolio will be at:
   https://YOUR-USERNAME.github.io/ai-operations-portfolio/

DEEP LINKS
#artifact-1  MTA AI auto-answer evaluation
#artifact-2  Zone reporting
#artifact-3  Comparative agent performance
#artifact-4  Recruiting-to-retention people analytics dashboard

BEFORE MAKING PUBLIC
Review every description to ensure there is no proprietary employer information,
confidential reporting logic, internal source data, or unsupported results. The
recruiting/retention numbers are synthetic, and MTA AI evaluation is retrospective
simulation, not a deployed agency tool. Consider anonymizing zone/agent naming.

If using a different repository name, change the URL accordingly.
